"""SWARMICA training pipeline"""
