#!/usr/bin/env python3

"""SWARMICA Upload v13.0.0 - PyPI"""

import requests
import hashlib
import os
import glob

TOKEN = "YOUR_PYPI_TOKEN_HERE"

print("="*60)
print("🐝 SWARMICA v13.0.0 Upload - PyPI")
print("="*60)

# قراءة README.md
try:
    with open('README.md', 'r', encoding='utf-8') as f:
        readme = f.read()
    print(f"📄 README.md: {len(readme)} characters")
except:
    readme = "SWARMICA: Autonomous Physical Law Discovery System"
    print("📄 README.md: using default")

# البحث عن ملفات التوزيع
wheel_files = glob.glob("dist/*.whl")
tar_files = glob.glob("dist/*.tar.gz")

if not wheel_files and not tar_files:
    print("\n❌ No distribution files. Building package...")
    os.system("python -m build")
    
    wheel_files = glob.glob("dist/*.whl")
    tar_files = glob.glob("dist/*.tar.gz")

print(f"\n📦 Files:")
for f in wheel_files + tar_files:
    print(f"   • {os.path.basename(f)}")

for filepath in wheel_files + tar_files:
    filename = os.path.basename(filepath)
    print(f"\n📤 Uploading: {filename}")

    # Determine file type
    if filename.endswith('.tar.gz'):
        filetype = 'sdist'
        pyversion = 'source'
    else:
        filetype = 'bdist_wheel'
        pyversion = 'py3'

    # Calculate hashes
    with open(filepath, 'rb') as f:
        content = f.read()
    md5_hash = hashlib.md5(content).hexdigest()
    sha256_hash = hashlib.sha256(content).hexdigest()

    # Upload data
    data = {
        ':action': 'file_upload',
        'metadata_version': '2.1',
        'name': 'swarmica-engine',
        'version': '13.0.0',
        'filetype': filetype,
        'pyversion': pyversion,
        'md5_digest': md5_hash,
        'sha256_digest': sha256_hash,
        'description': readme,
        'description_content_type': 'text/markdown',
        'author': 'Samir Baladi',
        'author_email': 'gitdeeper@gmail.com',
        'license': 'MIT',
        'summary': 'SWARMICA: Autonomous Physical Law Discovery System - From Classical Mechanics to Neural Operator Physics',
        'home_page': 'https://swarmica.netlify.app',
        'requires_python': '>=3.11',
        'keywords': 'swarm-intelligence, collective-stability, variational-mechanics, continuum-active-matter, lagrangian-mechanics, kuramoto-synchronization, pde-discovery, neural-operators, hamiltonian-systems'
    }

    # Upload file
    with open(filepath, 'rb') as f:
        response = requests.post(
            'https://upload.pypi.org/legacy/',
            files={'content': (filename, f, 'application/octet-stream')},
            data=data,
            auth=('__token__', TOKEN),
            timeout=60,
            headers={'User-Agent': 'SWARMICA-Uploader/1.0'}
        )

    print(f"   Status: {response.status_code}")

    if response.status_code == 200:
        print("   ✅✅✅ SUCCESS!")
    else:
        print(f"   ❌ Error: {response.text[:200]}")

print("\n" + "="*60)
print("🔗 https://pypi.org/project/swarmica-engine/13.0.0/")
print("="*60)
