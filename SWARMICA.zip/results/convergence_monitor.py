#!/usr/bin/env python3
"""Monitor convergence to global attractor Q*"""

import math
from typing import List, Tuple, Optional
from dataclasses import dataclass


@dataclass
class ConvergenceMonitor:
    """Monitor convergence of swarm to target configuration"""
    
    convergence_threshold: float = 0.01
    convergence_window: int = 50
    
    def __post_init__(self):
        self.distance_history = []
        self.convergence_step = -1
        self.convergence_time = -1.0
    
    def update(self, distance: float, step: int, dt: float = 0.001):
        """Update with current distance to target"""
        self.distance_history.append((step, distance))
        
        # Check convergence
        if self.convergence_step == -1 and distance < self.convergence_threshold:
            # Require staying below threshold for convergence_window
            recent = self.distance_history[-self.convergence_window:]
            if len(recent) >= self.convergence_window:
                if all(d < self.convergence_threshold for _, d in recent):
                    self.convergence_step = step
                    self.convergence_time = step * dt
    
    @property
    def current_distance(self) -> float:
        """Current distance to target"""
        return self.distance_history[-1][1] if self.distance_history else float('inf')
    
    @property
    def is_converged(self) -> bool:
        """Check if swarm has converged"""
        return self.convergence_step != -1
    
    def get_settling_time(self, tolerance: float = 0.05) -> int:
        """Get step when distance entered tolerance band"""
        for step, dist in self.distance_history:
            if dist < tolerance:
                return step
        return -1
    
    def compute_convergence_rate(self) -> Optional[float]:
        """Compute exponential convergence rate σ"""
        if len(self.distance_history) < 10:
            return None
        
        # Use last 10 points to estimate rate
        recent = self.distance_history[-10:]
        if not recent or recent[0][1] <= 0:
            return None
        
        ratio = recent[-1][1] / recent[0][1]
        if ratio <= 0:
            return None
        
        steps = recent[-1][0] - recent[0][0]
        if steps == 0:
            return None
        
        return -math.log(ratio) / steps
    
    def generate_report(self) -> str:
        """Generate convergence report"""
        report = []
        report.append("=" * 50)
        report.append("🎯 Convergence Report")
        report.append("=" * 50)
        report.append(f"Current distance:    {self.current_distance:.6f}")
        report.append(f"Threshold:           {self.convergence_threshold}")
        report.append(f"Converged:           {'Yes' if self.is_converged else 'No'}")
        
        if self.is_converged:
            report.append(f"Convergence step:    {self.convergence_step}")
            report.append(f"Convergence time:    {self.convergence_time:.3f}s")
        
        rate = self.compute_convergence_rate()
        if rate:
            report.append(f"Convergence rate σ:  {rate:.4f}")
            report.append(f"Time constant τ:     {1/rate:.1f} steps")
        
        report.append("=" * 50)
        return "\n".join(report)
    
    def reset(self):
        """Reset monitor"""
        self.distance_history = []
        self.convergence_step = -1
        self.convergence_time = -1.0


def compute_distance_to_target(q: List[float], q_star: List[float]) -> float:
    """Compute Euclidean distance between current and target configuration"""
    distance = 0.0
    for i in range(min(len(q), len(q_star))):
        diff = q[i] - q_star[i]
        distance += diff * diff
    return math.sqrt(distance)


def compute_weighted_distance(q: List[float], q_star: List[float], 
                              weights: List[float]) -> float:
    """Compute weighted distance to target"""
    distance = 0.0
    for i in range(min(len(q), len(q_star), len(weights))):
        diff = q[i] - q_star[i]
        distance += weights[i] * diff * diff
    return math.sqrt(distance)


if __name__ == '__main__':
    # Example usage
    monitor = ConvergenceMonitor(convergence_threshold=0.01)
    
    # Simulate decreasing distance
    import random
    for step in range(300):
        distance = 1.0 * math.exp(-step / 50) + random.uniform(-0.01, 0.01)
        monitor.update(max(0.0, distance), step, dt=0.001)
    
    print(monitor.generate_report())
