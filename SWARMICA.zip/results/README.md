# Results Directory

This directory stores simulation results, reports, and analysis from SWARMICA experiments.

## Directory Structure

```

results/
├── csi_reports/        # CSI analysis reports
├── convergence_plots/  # Convergence visualization data
├── entropy_maps/       # Entropy mapping results
├── experiments/        # Experiment-specific data
├── logs/               # Simulation logs
├── report_generator.py # Generate reports from results
├── csi_analyzer.py     # CSI analysis utilities
├── entropy_tracker.py  # Entropy tracking utilities
├── convergence_monitor.py # Convergence monitoring
└── README.md          # This file

```

## Usage

### Saving Results

```python
from results.report_generator import ResultSaver, create_result_from_engine
from swarmica import SwarmEngine, SwarmConfig

config = SwarmConfig(n_agents=100)
engine = SwarmEngine(config)
for _ in range(500):
    engine.step()

result = create_result_from_engine(engine, scenario="S1")
saver = ResultSaver(".")
saver.save_json(result)
saver.save_pickle(result)
```

Generating Reports

```python
from results.report_generator import ReportGenerator

report = ReportGenerator()
report.add_result(result)
print(report.generate_summary())
report.generate_csv("my_results.csv")
report.generate_markdown("my_report.md")
```

Analyzing CSI

```python
from results.csi_analyzer import CSIAnalyzer

analyzer = CSIAnalyzer()
for csi in csi_history:
    analyzer.add_reading(csi)
print(analyzer.generate_report())
```

Tracking Entropy

```python
from results.entropy_tracker import EntropyTracker

tracker = EntropyTracker()
for entropy in entropy_history:
    tracker.update(entropy)
print(tracker.generate_entropy_report())
```

Monitoring Convergence

```python
from results.convergence_monitor import ConvergenceMonitor, compute_distance_to_target

monitor = ConvergenceMonitor()
distance = compute_distance_to_target(q_current, q_target)
monitor.update(distance, step)
print(monitor.generate_report())
```

File Naming Convention

· JSON: result_YYYYMMDD_HHMMSS.json
· Pickle: result_YYYYMMDD_HHMMSS.pkl
· CSV: results_<scenario>_<timestamp>.csv
· Report: report_<timestamp>.md

Data Retention

Results files are not tracked by git (.gitkeep only). Please archive important results manually.
