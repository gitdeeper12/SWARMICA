#!/usr/bin/env python3
"""Analyze Collective Stability Index (CSI) from simulation results"""

import math
from typing import List, Dict, Tuple
from collections import defaultdict


class CSIAnalyzer:
    """Analyze CSI metrics from swarm simulations"""
    
    def __init__(self):
        self.csi_data = []
        self.entropy_data = []
        self.convergence_data = []
    
    def add_reading(self, csi: float, entropy: float = None, step: int = None):
        """Add a single reading"""
        self.csi_data.append(csi)
        if entropy is not None:
            self.entropy_data.append(entropy)
        if step is not None:
            self.convergence_data.append((step, csi))
    
    @property
    def mean_csi(self) -> float:
        """Mean CSI over all readings"""
        if not self.csi_data:
            return 0.0
        return sum(self.csi_data) / len(self.csi_data)
    
    @property
    def max_csi(self) -> float:
        """Maximum CSI achieved"""
        return max(self.csi_data) if self.csi_data else 0.0
    
    @property
    def min_csi(self) -> float:
        """Minimum CSI recorded"""
        return min(self.csi_data) if self.csi_data else 0.0
    
    @property
    def std_csi(self) -> float:
        """Standard deviation of CSI"""
        if len(self.csi_data) < 2:
            return 0.0
        m = self.mean_csi
        variance = sum((x - m) ** 2 for x in self.csi_data) / len(self.csi_data)
        return math.sqrt(variance)
    
    @property
    def final_csi(self) -> float:
        """Most recent CSI value"""
        return self.csi_data[-1] if self.csi_data else 0.0
    
    def get_stability_rating(self) -> str:
        """Get stability rating based on final CSI"""
        csi = self.final_csi
        if csi >= 0.95:
            return "Excellent"
        elif csi >= 0.90:
            return "Good"
        elif csi >= 0.80:
            return "Fair"
        elif csi >= 0.70:
            return "Poor"
        else:
            return "Unstable"
    
    def get_convergence_step(self, threshold: float = 0.9) -> int:
        """Get step number when CSI first exceeded threshold"""
        for step, csi in self.convergence_data:
            if csi >= threshold:
                return step
        return -1
    
    @property
    def entropy_reduction(self) -> float:
        """Calculate entropy reduction ratio"""
        if len(self.entropy_data) < 2:
            return 0.0
        initial = self.entropy_data[0]
        final = self.entropy_data[-1]
        if initial == 0:
            return 1.0
        return 1.0 - (final / initial)
    
    def generate_report(self) -> str:
        """Generate text report"""
        report = []
        report.append("=" * 50)
        report.append("📊 CSI Analysis Report")
        report.append("=" * 50)
        report.append(f"Total readings:     {len(self.csi_data)}")
        report.append(f"Mean CSI:           {self.mean_csi:.4f}")
        report.append(f"Std CSI:            {self.std_csi:.4f}")
        report.append(f"Max CSI:            {self.max_csi:.4f}")
        report.append(f"Min CSI:            {self.min_csi:.4f}")
        report.append(f"Final CSI:          {self.final_csi:.4f}")
        report.append(f"Stability Rating:   {self.get_stability_rating()}")
        if self.entropy_data:
            report.append(f"Entropy Reduction:  {self.entropy_reduction:.2%}")
        conv_step = self.get_convergence_step()
        if conv_step > 0:
            report.append(f"Convergence step:   {conv_step}")
        report.append("=" * 50)
        return "\n".join(report)
    
    def reset(self):
        """Reset all data"""
        self.csi_data = []
        self.entropy_data = []
        self.convergence_data = []


def analyze_multiple_runs(runs_csi: List[List[float]]) -> Dict:
    """Analyze multiple simulation runs"""
    results = {
        'mean_final_csi': 0.0,
        'std_final_csi': 0.0,
        'min_final_csi': 0.0,
        'max_final_csi': 0.0,
        'success_rate': 0.0
    }
    
    final_csi_values = [run[-1] for run in runs_csi if run]
    
    if final_csi_values:
        results['mean_final_csi'] = sum(final_csi_values) / len(final_csi_values)
        results['std_final_csi'] = math.sqrt(
            sum((v - results['mean_final_csi']) ** 2 for v in final_csi_values) / len(final_csi_values)
        )
        results['min_final_csi'] = min(final_csi_values)
        results['max_final_csi'] = max(final_csi_values)
        results['success_rate'] = sum(1 for v in final_csi_values if v >= 0.9) / len(final_csi_values)
    
    return results


if __name__ == '__main__':
    # Example usage
    analyzer = CSIAnalyzer()
    
    # Simulate some CSI readings
    import random
    csi_values = [0.3 + (i / 100) * 0.7 + random.uniform(-0.05, 0.05) for i in range(200)]
    
    for i, csi in enumerate(csi_values):
        analyzer.add_reading(min(1.0, max(0.0, csi)), step=i)
    
    print(analyzer.generate_report())
