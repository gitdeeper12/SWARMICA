#!/usr/bin/env python3
"""Generate reports and save results from SWARMICA simulations"""

import json
import pickle
import time
import math
from datetime import datetime
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass, asdict


@dataclass
class SimulationResult:
    """Store simulation results"""
    timestamp: str
    scenario: str
    n_agents: int
    modality: str
    final_csi: float
    final_entropy: float
    eri: float
    convergence_step: int
    convergence_time: float
    csi_history: List[float]
    entropy_history: List[float]
    metadata: Dict[str, Any]


class ResultSaver:
    """Save and load simulation results"""
    
    def __init__(self, results_dir: str = "."):
        self.results_dir = results_dir
    
    def save_json(self, result: SimulationResult, filename: str = None):
        """Save result as JSON"""
        if filename is None:
            filename = f"result_{result.timestamp}.json"
        
        data = asdict(result)
        # Convert lists to serializable format
        data['csi_history'] = result.csi_history[-100:]  # Keep last 100 for size
        data['entropy_history'] = result.entropy_history[-100:]
        
        filepath = f"{self.results_dir}/{filename}"
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
        print(f"✅ Saved JSON: {filepath}")
        return filepath
    
    def save_pickle(self, result: SimulationResult, filename: str = None):
        """Save result as pickle"""
        if filename is None:
            filename = f"result_{result.timestamp}.pkl"
        
        filepath = f"{self.results_dir}/{filename}"
        with open(filepath, 'wb') as f:
            pickle.dump(result, f)
        print(f"✅ Saved pickle: {filepath}")
        return filepath
    
    def load_json(self, filepath: str) -> Dict:
        """Load JSON result"""
        with open(filepath, 'r') as f:
            return json.load(f)
    
    def load_pickle(self, filepath: str) -> SimulationResult:
        """Load pickle result"""
        with open(filepath, 'rb') as f:
            return pickle.load(f)


class ReportGenerator:
    """Generate formatted reports from simulation results"""
    
    def __init__(self):
        self.results = []
    
    def add_result(self, result: SimulationResult):
        """Add result to report"""
        self.results.append(result)
    
    def generate_summary(self) -> str:
        """Generate summary report"""
        if not self.results:
            return "No results to report"
        
        summary = []
        summary.append("=" * 60)
        summary.append("🐝 SWARMICA SIMULATION REPORT")
        summary.append("=" * 60)
        summary.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        summary.append(f"Total simulations: {len(self.results)}")
        summary.append("")
        
        # Calculate averages
        avg_csi = sum(r.final_csi for r in self.results) / len(self.results)
        avg_eri = sum(r.eri for r in self.results) / len(self.results)
        avg_convergence = sum(r.convergence_step for r in self.results) / len(self.results)
        
        summary.append("📊 AGGREGATE METRICS")
        summary.append("-" * 40)
        summary.append(f"Mean Final CSI:        {avg_csi:.4f}")
        summary.append(f"Mean ERI:               {avg_eri:.4f}")
        summary.append(f"Mean Convergence Step: {avg_convergence:.1f}")
        summary.append("")
        
        # Per-scenario breakdown
        summary.append("📈 PER-SCENARIO BREAKDOWN")
        summary.append("-" * 40)
        
        scenarios = {}
        for r in self.results:
            if r.scenario not in scenarios:
                scenarios[r.scenario] = {'csi': [], 'eri': [], 'count': 0}
            scenarios[r.scenario]['csi'].append(r.final_csi)
            scenarios[r.scenario]['eri'].append(r.eri)
            scenarios[r.scenario]['count'] += 1
        
        for scenario, data in scenarios.items():
            avg_csi_scene = sum(data['csi']) / len(data['csi'])
            avg_eri_scene = sum(data['eri']) / len(data['eri'])
            summary.append(f"{scenario}: CSI={avg_csi_scene:.4f} | ERI={avg_eri_scene:.4f} (n={data['count']})")
        
        summary.append("")
        summary.append("=" * 60)
        
        return "\n".join(summary)
    
    def generate_csv(self, filename: str = "results.csv") -> str:
        """Generate CSV from results"""
        if not self.results:
            return ""
        
        import csv
        filepath = f"results/{filename}"
        
        with open(filepath, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['timestamp', 'scenario', 'n_agents', 'modality', 
                           'final_csi', 'eri', 'convergence_step'])
            
            for r in self.results:
                writer.writerow([
                    r.timestamp, r.scenario, r.n_agents, r.modality,
                    f"{r.final_csi:.4f}", f"{r.eri:.4f}", r.convergence_step
                ])
        
        print(f"✅ CSV saved: {filepath}")
        return filepath
    
    def generate_markdown(self, filename: str = "report.md") -> str:
        """Generate Markdown report"""
        if not self.results:
            return ""
        
        lines = []
        lines.append("# SWARMICA Simulation Report")
        lines.append(f"*Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*")
        lines.append("")
        lines.append("## Summary")
        lines.append("")
        
        avg_csi = sum(r.final_csi for r in self.results) / len(self.results)
        avg_eri = sum(r.eri for r in self.results) / len(self.results)
        
        lines.append(f"- **Total Simulations:** {len(self.results)}")
        lines.append(f"- **Mean Final CSI:** {avg_csi:.4f}")
        lines.append(f"- **Mean ERI:** {avg_eri:.4f}")
        lines.append("")
        lines.append("## Individual Results")
        lines.append("")
        lines.append("| Scenario | N | Modality | Final CSI | ERI | Convergence |")
        lines.append("|----------|---|----------|-----------|-----|-------------|")
        
        for r in self.results:
            lines.append(f"| {r.scenario} | {r.n_agents} | {r.modality} | {r.final_csi:.4f} | {r.eri:.4f} | {r.convergence_step} |")
        
        filepath = f"results/{filename}"
        with open(filepath, 'w') as f:
            f.write("\n".join(lines))
        
        print(f"✅ Markdown saved: {filepath}")
        return filepath


def create_result_from_engine(engine, scenario: str = "S1", 
                               n_agents: int = 100) -> SimulationResult:
    """Create SimulationResult from running engine"""
    from swarmica import SwarmEngine
    
    # Get history from engine
    csi_history = engine._csi_history if hasattr(engine, '_csi_history') else [engine.get_csi()]
    entropy_history = engine._entropy_history if hasattr(engine, '_entropy_history') else [engine.get_structural_entropy()]
    
    # Find convergence step (CSI > 0.9)
    convergence_step = len(csi_history)
    for i, csi in enumerate(csi_history):
        if csi > 0.9:
            convergence_step = i
            break
    
    result = SimulationResult(
        timestamp=datetime.now().strftime("%Y%m%d_%H%M%S"),
        scenario=scenario,
        n_agents=n_agents,
        modality=engine.config.modality,
        final_csi=engine.get_csi(),
        final_entropy=engine.get_structural_entropy(),
        eri=engine.get_eri(),
        convergence_step=convergence_step,
        convergence_time=convergence_step * engine.config.dt,
        csi_history=csi_history,
        entropy_history=entropy_history,
        metadata={
            'version': '1.0.0',
            'alpha': engine.config.alpha,
            'k_coupling': engine.config.k_coupling,
            'mu_dissipation': engine.config.mu_dissipation,
            'n_basis': engine.config.n_basis,
            'sos_degree': engine.config.sos_degree
        }
    )
    return result


# Example usage
if __name__ == '__main__':
    import sys
    sys.path.insert(0, '..')
    from swarmica import SwarmEngine, SwarmConfig
    
    # Run a quick simulation
    config = SwarmConfig(n_agents=50, modality='aerial')
    engine = SwarmEngine(config)
    
    for _ in range(500):
        engine.step()
    
    # Create result
    result = create_result_from_engine(engine, scenario="S1", n_agents=50)
    
    # Save
    saver = ResultSaver(".")
    saver.save_json(result)
    saver.save_pickle(result)
    
    # Generate report
    report = ReportGenerator()
    report.add_result(result)
    print(report.generate_summary())
