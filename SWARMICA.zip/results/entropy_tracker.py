#!/usr/bin/env python3
"""Track structural entropy S_struct in swarm simulations"""

import math
from typing import List, Dict, Tuple
from dataclasses import dataclass


@dataclass
class EntropyTracker:
    """Track structural entropy of swarm"""
    
    history: List[float] = None
    _min_entropy: float = 0.0
    
    def __post_init__(self):
        self.history = []
    
    def update(self, entropy: float):
        """Update entropy history"""
        self.history.append(entropy)
        if len(self.history) == 1:
            self._min_entropy = entropy
        else:
            self._min_entropy = min(self._min_entropy, entropy)
    
    @property
    def current(self) -> float:
        """Current entropy"""
        return self.history[-1] if self.history else 0.0
    
    @property
    def initial(self) -> float:
        """Initial entropy"""
        return self.history[0] if self.history else 0.0
    
    @property
    def minimum(self) -> float:
        """Minimum entropy achieved"""
        return self._min_entropy
    
    @property
    def reduction(self) -> float:
        """Entropy reduction ratio: 1 - S_final / S_initial"""
        if self.initial == 0:
            return 1.0
        return 1.0 - (self.current / self.initial)
    
    @property
    def reduction_index(self) -> float:
        """Entropy Reduction Index (ERI)"""
        return self.reduction
    
    def get_entropy_floor_distance(self, theoretical_min: float = 0.0) -> float:
        """Distance to theoretical entropy floor"""
        return self.current - theoretical_min
    
    def generate_entropy_report(self) -> str:
        """Generate entropy analysis report"""
        if not self.history:
            return "No entropy data"
        
        report = []
        report.append("=" * 50)
        report.append("📉 Structural Entropy Report")
        report.append("=" * 50)
        report.append(f"Initial S_struct:    {self.initial:.4f}")
        report.append(f"Final S_struct:      {self.current:.4f}")
        report.append(f"Minimum S_struct:    {self.minimum:.4f}")
        report.append(f"Entropy Reduction:   {self.reduction:.2%}")
        report.append(f"ERI:                 {self.reduction_index:.4f}")
        report.append("=" * 50)
        return "\n".join(report)
    
    def reset(self):
        """Reset tracker"""
        self.history = []
        self._min_entropy = 0.0


def compute_entropy_from_probabilities(probs: List[float]) -> float:
    """Compute Shannon entropy from probability distribution"""
    entropy = 0.0
    for p in probs:
        if p > 0:
            entropy -= p * math.log(p)
    return entropy


def compute_normalized_entropy(probs: List[float]) -> float:
    """Compute normalized entropy in [0, 1]"""
    entropy = compute_entropy_from_probabilities(probs)
    max_entropy = math.log(len(probs)) if len(probs) > 1 else 1.0
    return entropy / max_entropy if max_entropy > 0 else 0.0


if __name__ == '__main__':
    # Example usage
    tracker = EntropyTracker()
    
    # Simulate entropy decreasing over time
    import random
    entropy_values = [0.9 * math.exp(-i / 50) + random.uniform(-0.02, 0.02) for i in range(200)]
    
    for e in entropy_values:
        tracker.update(max(0.01, e))
    
    print(tracker.generate_entropy_report())
